package circumference;
import java.util.*;

public class circumference {
	public static void main(String args[]) {
		Scanner obj = new Scanner(System.in);
		
		System.out.println("Enter radius:");
		double rad = obj.nextDouble();
		
		System.out.println("Circumference of circle is:"+ (2*3.14*rad));
   }

}
