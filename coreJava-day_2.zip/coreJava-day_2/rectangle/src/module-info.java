/**
 * 
 */
/**
 * 
 */
module rectangle {
}