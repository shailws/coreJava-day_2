package circle;
import java.util.*;

public class Circle {
	public static void main(String srsg[]) {
		Scanner obj = new Scanner(System.in);
		System.out.println("Enter radius of circle:");
		  double radius = obj.nextDouble();
		  System.out.println("Area of circle is:" + 3.14*radius*radius);
	}
}
