package triangle;
import java.util.*;

public class Triangle {
	public static void main(String args[]) {
		Scanner obj = new Scanner(System.in);
		
		System.out.println("Enter perpendicular height:");
		double perheight = obj.nextDouble();
		
		System.out.println("Enter Base:");
		double base = obj.nextDouble();
		
		System.out.println("Area of Triangle is:" + (base*perheight)/2);
	}
}
