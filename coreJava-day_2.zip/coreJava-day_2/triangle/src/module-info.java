/**
 * 
 */
/**
 * 
 */
module triangle {
}