package arithmatic;
import java.util.*;
public class Arithmatic {
	public static void main(String args[]) {
		Scanner obj = new Scanner(System.in);
		
		System.out.println("Enter first number:");
		int firstnum = obj.nextInt();
		
		System.out.println("Enter second number:");
		int secondnum = obj.nextInt();
		
		int add = firstnum + secondnum;
		int sub = firstnum - secondnum;
		int mul = firstnum * secondnum;
		int div = firstnum / secondnum;
		int mod = firstnum % secondnum;
		
		System.out.println("Addition = " + add);
		System.out.println("Substraction = " + sub);
		System.out.println("Multiplication = " + mul);
		System.out.println("Division = " + div);
		System.out.println("Modulus = " + mod);
	}
	
}
