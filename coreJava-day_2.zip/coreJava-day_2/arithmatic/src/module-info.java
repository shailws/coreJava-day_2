/**
 * 
 */
/**
 * 
 */
module arithmatic {
}